package com.policymanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.policymanagement.model.NomineeRelations;
@Repository
public interface NomineeRelationsRepository extends JpaRepository<NomineeRelations, Integer>   {
	 List<NomineeRelations> findAll();
}