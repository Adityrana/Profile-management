package com.policymanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.policymanagement.model.UserNominees;
import com.policymanagement.model.UserProfiles;

import jakarta.transaction.Transactional;
@Repository
public interface UserNomineesRepository extends JpaRepository<UserNominees, Integer> {
	UserNominees findByUserProfile(UserProfiles userProfile);
	@Query(value = "select * from user_nominees where username=?",nativeQuery = true)
	UserNominees findByUsername(@Param("?") String username);

	

	 @Transactional
	 @Modifying
	 @Query(value = "DELETE FROM user_nominees WHERE username = ?", nativeQuery = true)
	    void deleteByUsername(@Param("?") String username);

}
