package com.policymanagement.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.policymanagement.exception.Only1NomineeAllowedException;
import com.policymanagement.model.UserNominees;
import com.policymanagement.services.UserNomineesService;

@RestController
@RequestMapping("/api")
public class UserNomineesController {

    private static final Logger logger = LoggerFactory.getLogger(UserNomineesController.class);

    @Autowired
    private UserNomineesService userNomineesService;
    
    @CrossOrigin(origins="http://localhost:4200")
    @GetMapping("/view")
    public ResponseEntity<List<UserNominees>> viewAllNominees() {
        logger.info("Fetching all nominees");
        return userNomineesService.ViewUserNominee();
    }

    @CrossOrigin(origins="http://localhost:4200")
    @PostMapping("/profile/{username}/nominee")
    public ResponseEntity<String> addNominee(@PathVariable String username, @RequestBody UserNominees nominee) throws Only1NomineeAllowedException {
        logger.info("Adding nominee for user: {}", username);
        return userNomineesService.addNominee(username, nominee);
    }
    @CrossOrigin(origins="http://localhost:4200")
    @GetMapping("profile/{username}/nominee")
    public UserNominees findNominee(@PathVariable String username) {
        logger.info("Finding nominee for user: {}", username);
        return userNomineesService.findNominee(username);
    }
    @CrossOrigin(origins="http://localhost:4200")
    @DeleteMapping("profile/{username}/nominee")
    public void deleteNominee(@PathVariable String username) {
        logger.info("Deleting nominee for user: {}", username);
        userNomineesService.deleteNominee(username);
    }
    @ExceptionHandler(Only1NomineeAllowedException.class)
    public ResponseEntity<String> handleOnly1NomineeAllowedException(Only1NomineeAllowedException e) {
        logger.error("Error occurred: {}", e.getMessage());
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }
}
