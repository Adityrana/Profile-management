package com.policymanagement.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.policymanagement.model.NomineeRelations;
import com.policymanagement.repository.NomineeRelationsRepository;
import com.policymanagement.services.NomineeRelationsServices;

@RestController
@RequestMapping("/api")
public class NomineeRelationsController {

    private static final Logger logger = LoggerFactory.getLogger(NomineeRelationsController.class);

    @Autowired
    private NomineeRelationsServices nomineeRelationsServices;
    
    @Autowired
    private NomineeRelationsRepository repo;

    @GetMapping("/nomineetypes")
    public ResponseEntity<List<NomineeRelations>> viewNomineeTypes() {
        logger.info("Fetching nominee types");
        ResponseEntity<List<NomineeRelations>> response = nomineeRelationsServices.nomineetype();
        logger.info("Fetched {} nominee types", response.getBody().size());
        return response;
    }
    
    @PostMapping("/addNominee")
    public String addNominee(@RequestBody NomineeRelations obj) {
    	repo.save(obj);
    	return "Data saved";
    }
}