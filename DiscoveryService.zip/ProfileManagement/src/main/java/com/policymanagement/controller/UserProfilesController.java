
package com.policymanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.policymanagement.model.UserProfiles;
import com.policymanagement.services.UserProfilesServices;

@RestController
@RequestMapping("/api")
public class UserProfilesController {

    @Autowired
    private UserProfilesServices userProfilesServices;

	@GetMapping("/userprofilesview")
    public ResponseEntity<List<UserProfiles>> viewAllProfiles() {
        return userProfilesServices.ViewUserProfile();
    }
      @CrossOrigin("http://localhost:4200")
	  @PostMapping("/profile")
	  public ResponseEntity<String> addProfile(@RequestBody UserProfiles userProfile) throws Exception {
		    ResponseEntity<String> addProfile = userProfilesServices.addProfile(userProfile);
		    return new ResponseEntity<> (addProfile + userProfile.getUsername(), HttpStatus.CREATED);
		}
}