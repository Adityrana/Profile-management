package com.policymanagement.exception;

public class NationalityCheckException extends Exception{
	public NationalityCheckException(String message) {
	super(message);
}

}
