package com.policymanagement.services;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.policymanagement.exception.Only1NomineeAllowedException;
import com.policymanagement.model.UserNominees;
import com.policymanagement.model.UserProfiles;
import com.policymanagement.repository.NomineeRelationsRepository;
import com.policymanagement.repository.UserNomineesRepository;
import com.policymanagement.repository.UserProfilesrepository;

@Service
public class UserNomineesService implements UserNomineesServices{
	@Autowired
	UserNomineesRepository userNomineesRepository;
	@Autowired
	UserProfilesrepository  userProfilesRepository;
	@Autowired
    NomineeRelationsRepository  nomineeRelationsRepository;

	public ResponseEntity<List<UserNominees>> ViewUserNominee() {
		return new ResponseEntity<>(userNomineesRepository.findAll(), HttpStatus.FOUND);
	}
	
	
	public UserNominees findNominee(String username){
		return userNomineesRepository.findByUsername(username);
	}

	public void deleteNominee(String username) {
		userNomineesRepository.deleteByUsername(username);

	}
	public ResponseEntity<String> addNominee(String username, UserNominees nominee) throws Only1NomineeAllowedException{
	    UserProfiles userProfile = userProfilesRepository.findByUsername(username);
	    if (userProfile == null) {
	        return new ResponseEntity<String>("User not found", HttpStatus.NOT_FOUND);
	    }

	    if (userNomineesRepository.findByUserProfile(userProfile) != null) {
	    	throw new Only1NomineeAllowedException("Only one nominee can be added");
	    }

//	
	    userNomineesRepository.save(nominee);

	    return new ResponseEntity<String>("Nominee added.", HttpStatus.CREATED);
	}


	
}


	

