package com.policymanagement.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.policymanagement.model.NomineeRelations;
import com.policymanagement.repository.NomineeRelationsRepository;

@Service
public class NomineeRelationsService implements NomineeRelationsServices {
    @Autowired
	NomineeRelationsRepository repo;
	
    public ResponseEntity<List<NomineeRelations>> nomineetype(){
    	return new ResponseEntity<>(repo.findAll(), HttpStatus.OK);
    }

	
}


