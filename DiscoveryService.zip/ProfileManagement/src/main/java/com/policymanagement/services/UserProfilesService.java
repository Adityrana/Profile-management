
package com.policymanagement.services;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.policymanagement.exception.NationalityCheckException;
import com.policymanagement.model.UserProfiles;
import com.policymanagement.repository.UserProfilesrepository;


@Service
public class UserProfilesService implements UserProfilesServices{

	@Autowired
	UserProfilesrepository obj;
	Logger logger = LoggerFactory.getLogger(UserProfilesService.class);

	public ResponseEntity<List<UserProfiles>> ViewUserProfile() {
		return new ResponseEntity<>(obj.findAll(), HttpStatus.FOUND);
	}

	public ResponseEntity<String> addProfile(UserProfiles prof) {
		if(prof.getNationality().equalsIgnoreCase("Indian")==false) {
			try {
				if(prof.getIdprooftype().equalsIgnoreCase("passport")==false) {
					throw new NationalityCheckException("Only acceptable ID proof type is passport");
				}
			}catch (NationalityCheckException e) {
				e.getStackTrace();
				return new ResponseEntity<>("Only acceptable ID proof type is passport", HttpStatus.BAD_REQUEST);
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		prof.setUsername(generateUsername(prof.getFirstname(), prof.getLastname()));
		obj.save(prof);
		return new ResponseEntity<>("Profile Added Successfully", HttpStatus.CREATED);
	}

	public String generateUsername(String firstName, String lastName) {
	    return firstName.substring(0, 2) + lastName.substring(0, 4) + String.format("%04d", (int) (Math.random() * 10000));
	}
}
