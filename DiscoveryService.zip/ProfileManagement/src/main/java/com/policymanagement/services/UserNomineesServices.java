package com.policymanagement.services;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.policymanagement.exception.Only1NomineeAllowedException;
import com.policymanagement.model.UserNominees;

@Service
public interface UserNomineesServices {

	ResponseEntity<List<UserNominees>> ViewUserNominee();



	void deleteNominee(String username);



	 ResponseEntity<String> addNominee(String username,UserNominees nominee) throws Only1NomineeAllowedException;
	 
	 UserNominees findNominee(String username);
	
}



