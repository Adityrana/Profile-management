package com.policymanagement.services;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.policymanagement.model.NomineeRelations;

@Service
public interface NomineeRelationsServices {

	ResponseEntity<List<NomineeRelations>> nomineetype();

	
}

