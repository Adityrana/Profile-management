package com.policymanagement.services;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.policymanagement.model.UserProfiles;

@Service
public interface UserProfilesServices {

	ResponseEntity<List<UserProfiles>> ViewUserProfile();

	ResponseEntity<String> addProfile(UserProfiles prof);

	String generateUsername(String firstName, String lastName);
}

