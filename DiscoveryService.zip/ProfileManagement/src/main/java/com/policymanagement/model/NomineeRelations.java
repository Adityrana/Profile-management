package com.policymanagement.model;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="nomineeRelations")
public class NomineeRelations {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="nomineerelationid")
    private int nomineeRelationId;
    private int type;
  


    public int getNomineeRelationId() {
		return nomineeRelationId;
	}

	public void setNomineeRelationId(int nomineeRelationId) {
		this.nomineeRelationId = nomineeRelationId;
	}

	public int getType() {
        return type;
    }

    // Setters


    public void setType(int type) {
        this.type = type;
    }
    
	@Override
	public String toString() {
		return "NomineeRelations [id=" + nomineeRelationId + ", type=" + type + "]";
	}
}


