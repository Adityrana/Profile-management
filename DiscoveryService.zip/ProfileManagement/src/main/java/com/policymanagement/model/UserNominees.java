package com.policymanagement.model;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "userNominees")
public class UserNominees {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String fullname;
	private Date dateofbirth;
	private String gender;
	private String idprooftype;
	private String idproofdocnumber;
	private String nationality;
    @Transient
	@ManyToOne
	@JoinColumn(name="nomineerelationid", referencedColumnName="nomineerelationid", nullable=false)
	private NomineeRelations nomineeRelation;
    
    private int nomineerelationid;
    @Transient
	@OneToOne
	@JoinColumn(name="username", nullable=false)
	private UserProfiles userProfile;

    private String username;
    
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIdprooftype() {
		return idprooftype;
	}

	public void setIdprooftype(String idprooftype) {
		this.idprooftype = idprooftype;
	}

	public String getIdproofdocnumber() {
		return idproofdocnumber;
	}

	public void setIdproofdocnumber(String idproofdocnumber) {
		this.idproofdocnumber = idproofdocnumber;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public NomineeRelations getNomineeRelation() {
		return nomineeRelation;
	}

	public void setNomineeRelation(NomineeRelations nomineeRelation) {
		this.nomineeRelation = nomineeRelation;
	}

	public UserProfiles getUserProfile() {
		return userProfile;
	}

	public int getNomineerelationid() {
		return nomineerelationid;
	}

	public void setNomineerelationid(int nomineerelationid) {
		this.nomineerelationid = nomineerelationid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setUserProfile(UserProfiles userProfile) {
		this.userProfile = userProfile;
	}

	@Override
	public String toString() {
		return "UserNominees [id=" + id + ", fullname=" + fullname + ", dateofbirth=" + dateofbirth + ", gender="
				+ gender + ", idprooftype=" + idprooftype + ", idproofdocnumber=" + idproofdocnumber + ", nationality="
				+ nationality + ", nomineeRelation=" + nomineeRelation + ", nomineerelationid=" + nomineerelationid
				+ ", userProfile=" + userProfile + ", username=" + username + "]";
	}

	

	
	

}
