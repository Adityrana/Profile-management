package com.PolicyManagement.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileManagementApplicationTests {

	

}

