package com.PolicyManagement.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.policymanagement.model.NomineeRelations;
import com.policymanagement.repository.NomineeRelationsRepository;
import com.policymanagement.services.NomineeRelationsService;

public class NomineeRelationsTest {

    @Mock
    private NomineeRelationsRepository repository;

    @InjectMocks
    private NomineeRelationsService service;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testNomineeType() {
        // Mock data
        NomineeRelations relation1 = new NomineeRelations();
        relation1.setNomineeRelationId(1);
        relation1.setType(1);

        NomineeRelations relation2 = new NomineeRelations();
        relation2.setNomineeRelationId(2);
        relation2.setType(2);

        List<NomineeRelations> nomineeRelationsList = Arrays.asList(relation1, relation2);

        // Mocking repository behavior
        when(repository.findAll()).thenReturn(nomineeRelationsList);

        
        
        
        // Call service method
        ResponseEntity<List<NomineeRelations>> responseEntity = service.nomineetype();

        // Verify the response
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(nomineeRelationsList, responseEntity.getBody());
    }
}
