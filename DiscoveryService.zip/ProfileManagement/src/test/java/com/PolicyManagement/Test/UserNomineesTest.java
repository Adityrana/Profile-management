package com.PolicyManagement.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.policymanagement.exception.Only1NomineeAllowedException;
import com.policymanagement.model.UserNominees;
import com.policymanagement.model.UserProfiles;
import com.policymanagement.repository.UserNomineesRepository;
import com.policymanagement.repository.UserProfilesrepository;
import com.policymanagement.services.UserNomineesService;

public class UserNomineesTest {

    @Mock
    private UserNomineesRepository userNomineesRepository;

    @Mock
    private UserProfilesrepository userProfilesRepository;

    @InjectMocks
    private UserNomineesService userNomineesService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testViewUserNominee() {
        // Mock data
        UserNominees nominee1 = new UserNominees();
        nominee1.setId(1);

        List<UserNominees> nomineesList = Arrays.asList(nominee1);

        // Mocking repository behavior
        when(userNomineesRepository.findAll()).thenReturn(nomineesList);

        // Call service method
        ResponseEntity<List<UserNominees>> responseEntity = userNomineesService.ViewUserNominee();

        // Verify the response
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertEquals(nomineesList, responseEntity.getBody());
    }

    @Test
    public void testAddNominee() throws Only1NomineeAllowedException {
        // Mock data
        UserProfiles userProfile = new UserProfiles();
        userProfile.setUsername("testUser");

        UserNominees nominee = new UserNominees();
        nominee.setUserProfile(userProfile);

        // Mocking repository behavior
        when(userProfilesRepository.findByUsername(eq("testUser"))).thenReturn(userProfile);
        when(userNomineesRepository.findByUserProfile(any(UserProfiles.class))).thenReturn(null);

        // Call service method
        ResponseEntity<String> responseEntity = userNomineesService.addNominee("testUser", nominee);

        // Verify the response
        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertEquals("Nominee added.", responseEntity.getBody());
    }

    @Test
    public void testAddNominee_Only1NomineeAllowedException() throws Only1NomineeAllowedException {
        
    	String username = "testUser";
        UserProfiles userProfile = new UserProfiles();
        userProfile.setUsername(username);
        UserNominees nominee = new UserNominees();

        when(userProfilesRepository.findByUsername(username)).thenReturn(userProfile);
        when(userNomineesRepository.findByUserProfile(userProfile)).thenReturn(null);
        when(userNomineesRepository.save(nominee)).thenReturn(nominee);

        ResponseEntity<String> response = userNomineesService.addNominee(username, nominee);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Nominee added.", response.getBody());
}
    @Test
    public void testFindNomineeByUsername() {
//       
    	
    	String username = "testUser";
      UserProfiles userProfile = new UserProfiles();
      userProfile.setUsername(username);
        UserNominees userNominee = new UserNominees();
        userNominee.setUserProfile(userProfile);

        when(userNomineesRepository.findByUsername(username)).thenReturn(userNominee);

        UserNominees found = userNomineesService.findNominee(username);

        assertEquals(userNominee, found);
        verify(userNomineesRepository, times(1)).findByUsername(username);
    }

    @Test
    public void testDeleteNomineeByUsername() {
//       
    	
    	String username = "testUser";

        doNothing().when(userNomineesRepository).deleteByUsername(username);

        userNomineesService.deleteNominee(username);

        verify(userNomineesRepository, times(1)).deleteByUsername(username);
    }
}

