package com.PolicyManagement.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.policymanagement.exception.NationalityCheckException;
import com.policymanagement.model.UserProfiles;
import com.policymanagement.repository.UserProfilesrepository;
import com.policymanagement.services.UserProfilesService;

public class UserProfilesTest {

    @Mock
    private UserProfilesrepository userProfileRepository;

    @InjectMocks
    private UserProfilesService userProfileService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testViewUserProfile() {
        // Mock data
        UserProfiles profile1 = new UserProfiles();
        profile1.setUsername("user1");

        UserProfiles profile2 = new UserProfiles();
        profile2.setUsername("user2");

        List<UserProfiles> profilesList = Arrays.asList(profile1, profile2);

        // Mocking repository behavior
        when(userProfileRepository.findAll()).thenReturn(profilesList);

        // Call service method
        ResponseEntity<?> responseEntity = userProfileService.ViewUserProfile();

        // Verify the response
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(profilesList, responseEntity.getBody());
    }

    @Test
    public void testAddProfile() throws Exception {
        // Mock data
        UserProfiles userProfile = new UserProfiles();
        userProfile.setUsername("JoDonu1234");
        userProfile.setFirstname("John");
        userProfile.setLastname("Donut");
        userProfile.setDateofbirth(Date.valueOf("1990-01-01"));
        userProfile.setGender("Male");
        userProfile.setProfession("Engineer");
        userProfile.setCurrentaddress("123 Main St, City");
        userProfile.setNationality("Indian");
        userProfile.setIdprooftype("passport");
        userProfile.setIdproofdocnumber("AB1234567");
        userProfile.setPhonenumber("1234567890");
        userProfile.setEmailaddress("john.doe@example.com");

        // Mocking repository behavior
        when(userProfileRepository.save(any(UserProfiles.class))).thenReturn(userProfile);

        // Call service method
        ResponseEntity<String> responseEntity = userProfileService.addProfile(userProfile);

        // Verify the response
        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertEquals("Profile Added Successfully", responseEntity.getBody());
    }

    @Test
    public void testAddProfile_NationalityCheckException() {
        // Mock data
        UserProfiles userProfile = new UserProfiles();
        userProfile.setNationality("American");
        userProfile.setIdprooftype("Passport");

        // Verify that NationalityCheckException is thrown
        assertThrows(NationalityCheckException.class, () -> {
            userProfileService.addProfile(userProfile);
        });
    }
}